<?php
# 同步返回页面
# Required File Includes
include("../../../init.php");
include("../../../includes/functions.php");
include("../../../includes/gatewayfunctions.php");
include("../../../includes/invoicefunctions.php");

class Shanpay {
	public function md5VerifyShan($p1, $p2,$p3,$sign,$key,$pid) {
		$prestr = $p1.$p2.$p3.$pid.$key;
		$mysgin = md5($prestr);
		if($mysgin == $sign) {
			return true;
		}else {
			return false;
		}
	}
}


$gatewaymodule = "shanpay";
$GATEWAY = getGatewayVariables($gatewaymodule);

$url			= $GATEWAY['systemurl'];
$companyname 	= $GATEWAY['companyname'];
$currency		= $GATEWAY['currency'];

if (!$GATEWAY["type"]) die("Module Not Activated"); 

$gatewayPID 			= $GATEWAY['pid'];
$gatewaySELLER_ID 	 	=$GATEWAY['seller_id'];
$gatewaySELLER_KEY 	= $GATEWAY['key'];
$shanpay = new Shanpay();


$shanNotify = $shanpay->md5VerifyShan($_REQUEST['out_order_no'],$_REQUEST['total_fee'],$_REQUEST['trade_status'],$_REQUEST['sign'],$gatewaySELLER_KEY,$gatewayPID);
if($shanNotify) {//验证成功
	if($_REQUEST['trade_status']=='TRADE_SUCCESS'){
			
			# Get Returned Variables
			$status = $_REQUEST['trade_status'];
			$invoiceid = $_REQUEST['out_order_no']; //获取传递过来的订单号
			$transid = $_REQUEST['trade_no'];       //获取传递过来的交易号
			$amount = $_REQUEST['total_fee'];       //获取传递过来的总价格
			$fee = 0;

			$paidcurrency = "CNY";
			$result = select_query( 'tblcurrencies', '', array( 'code' => $paidcurrency ));
			$data = mysql_fetch_array($result);
			$paidcurrencyid = $data['id'];

			$invoiceid = checkCbInvoiceID($invoiceid,$GATEWAY["name"]);
			$result = select_query( 'tblinvoices', '', array( 'id' => $invoiceid ) );
			$data = mysql_fetch_array( $result );
			$userid = $data['userid'];
			$currency = getCurrency( $userid );
			$amount = convertCurrency( $amount, $paidcurrencyid, $currency['id'] );
			checkCbTransID($transid);
			addInvoicePayment($invoiceid,$transid,$amount,$fee,$gatewaymodule);
			logTransaction($GATEWAY["name"],$_REQUEST,"Successful-A");
			echo 'success';
	}else{
		logTransaction($GATEWAY["name"],$_REQUEST,"Unsuccessful");
		echo "fail";//请不要修改或删除
	}
}else {
   echo "fail";//请不要修改或删除
}
?>